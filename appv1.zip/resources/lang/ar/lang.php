<?php

return [
    ///// User Management
    'btn_login' => 'دخول',
    'btn_forget' => 'هل نسيت كلمة المرور ؟',
    'btn_remember' => 'تذكرني',

    'Male' => 'ذكر',
    'Female' => 'انثى',
    'Password_is_wrong' => 'كلمة المرور غير صحيحة',
    'There_is_no_account_for_this_user' => 'لا بوجد حساب لهذا المستخدم',
    'Successfully_done' => 'تم بنجاح',
    'Sorry_phone_number_is_wrong' => 'نأسف , رقم الجوال غير صحيح',
    'Sorry_it_has_not_been_created' => 'نأسف , لم يتم التسجيل',
    'There_are_no_results' => 'عفوآ , لا يوجد نتائج',

];
