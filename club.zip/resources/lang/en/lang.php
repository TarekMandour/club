<?php

return [
    ///// User Management
    'btn_login' => 'Login',
    'btn_forget' => 'Forgot your password?',
    'btn_remember' => 'Remember me',
    'Male' => 'Male',
    'Female' => 'Female',
    'Password_is_wrong' => 'Password is wrong',
    'There_is_no_account_for_this_user' => 'There is no account for this user',
    'Successfully_done' => 'Successfully done',
    'Sorry_phone_number_is_wrong' => 'Sorry phone number is wrong',
    'Sorry_it_has_not_been_created' => 'Sorry it has not been created',
    'There_are_no_results' => 'There are no results',


];
